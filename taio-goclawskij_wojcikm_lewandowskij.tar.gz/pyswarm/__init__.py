"""
================================================================================
pyswarm: Particl swarm optimization (PSO) with constraint support
================================================================================

Author: Abraham Lee
Copyright: 2013-2014

"""
# from __future__ import absolute_import

__author__ = 'Abraham Lee'
__version__ = '0.6'

from pyswarm.pso import *
    
